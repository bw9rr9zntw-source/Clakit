# CineMax 🎬

A modern movie streaming UI built with Flutter — home feed with hero banner,
category browsing, search, a personal "My List", and a movie detail screen.

## Project structure

```
cinemax/
├── android/                # Native Android project (Gradle, manifests, icons)
├── ios/                    # Native iOS project skeleton (see note below)
├── lib/
│   ├── main.dart           # App entry point + theming
│   ├── core/
│   │   ├── constants/      # Colors, spacing, radius, strings
│   │   ├── utils/          # Responsive helpers
│   │   └── widgets/        # MovieCard, HorizontalMovieList
│   ├── data/
│   │   ├── models/         # Movie model
│   │   └── repositories/   # Mock movie data source
│   └── presentation/
│       ├── providers/      # AppProvider (theme + "My List" state)
│       ├── screens/        # home, search, downloads, profile, movie_detail, splash
│       └── widgets/        # MainNavScreen (bottom navigation)
├── test/                   # Basic widget smoke test
├── pubspec.yaml
└── analysis_options.yaml
```

## Run locally

```bash
flutter pub get
flutter run
```

## Build a release APK

```bash
flutter pub get
flutter build apk --release
```

The APK will be at `build/app/outputs/flutter-apk/app-release.apk`.

## Building on Codemagic / GitHub Actions

1. Push this whole folder to a new GitHub repository (keep the structure as-is).
2. In Codemagic, create a new Flutter app workflow pointing at the repo.
3. Use the default build script, or simply:
   ```bash
   flutter pub get
   flutter build apk --release
   ```
4. No extra configuration is required for a debug/unsigned release APK.
   For a **signed** release (Play Store), add your own keystore and a
   `key.properties` file, then update `android/app/build.gradle`
   (`signingConfigs`) accordingly — the project currently signs release
   builds with the debug key so it builds out of the box.

## Important notes

- **Gradle wrapper jar**: `android/gradle/wrapper/gradle-wrapper.jar` is a
  binary file that could not be generated in this offline environment.
  The first time you build (with internet access), run:
  ```bash
  cd android
  gradle wrapper --gradle-version 8.3
  cd ..
  ```
  if `./gradlew` complains it's missing. Most CI services (Codemagic,
  GitHub Actions with `subosito/flutter-action`) and Android Studio invoke
  `flutter`/`gradle` directly and will fetch everything automatically the
  first time you run `flutter pub get` / `flutter build apk` with network
  access, but if you hit a wrapper error, running the command above will
  fix it instantly.
- **iOS project file**: `ios/Runner.xcodeproj/project.pbxproj` (the Xcode
  project file itself) is not included, since it's a complex generated
  file that's unsafe to hand-write and only matters if you build for iOS.
  If you need to build/run on iOS or open the project in Xcode, run:
  ```bash
  flutter create --platforms=ios .
  ```
  from the project root once (with the Flutter SDK installed) to
  regenerate it — your existing `lib/`, `pubspec.yaml`, and `ios/Runner`
  assets will be preserved/merged.
- All movie posters/backdrops are placeholder images loaded from the
  network (picsum.photos) — swap in your own assets or an API in
  `lib/data/repositories/movie_repository.dart`.
