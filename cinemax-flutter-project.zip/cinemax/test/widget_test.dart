import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:provider/provider.dart';

import 'package:cinemax/presentation/providers/app_provider.dart';
import 'package:cinemax/presentation/widgets/main_nav_screen.dart';

void main() {
  testWidgets('App launches and shows the home tab', (tester) async {
    await tester.pumpWidget(
      ChangeNotifierProvider(
        create: (_) => AppProvider(),
        child: const MaterialApp(home: MainNavScreen()),
      ),
    );
    await tester.pump();

    // Bottom navigation bar should be present.
    expect(find.byType(NavigationBar), findsOneWidget);
  });
}
